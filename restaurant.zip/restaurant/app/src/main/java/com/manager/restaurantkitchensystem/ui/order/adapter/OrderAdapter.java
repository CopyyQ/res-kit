package com.manager.restaurantkitchensystem.ui.order.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.manager.restaurantkitchensystem.R;
import com.manager.restaurantkitchensystem.ui.order.OrderModel;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<OrderModel> orderList;
    private Runnable updateTotalPriceCallback;

    public OrderAdapter(List<OrderModel> orderList, Runnable updateTotalPriceCallback) {
        this.orderList = orderList;
        this.updateTotalPriceCallback = updateTotalPriceCallback;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        OrderModel order = orderList.get(position);

        // Hiển thị thông tin món ăn
        holder.foodNameTextView.setText(order.getName());
        holder.foodPriceTextView.setText(order.getPrice() + " VND");
        holder.foodQuantityTextView.setText(String.valueOf(order.getQuantity()));
        holder.foodImageView.setImageResource(order.getImageResId());

        // Xử lý sự kiện tăng số lượng
        holder.increaseButton.setOnClickListener(v -> {
            order.setQuantity(order.getQuantity() + 1);
            holder.foodQuantityTextView.setText(String.valueOf(order.getQuantity()));
            updateTotalPriceCallback.run(); // Cập nhật tổng giá
        });

        // Xử lý sự kiện giảm số lượng
        holder.decreaseButton.setOnClickListener(v -> {
            if (order.getQuantity() > 0) {
                order.setQuantity(order.getQuantity() - 1);
                holder.foodQuantityTextView.setText(String.valueOf(order.getQuantity()));
                updateTotalPriceCallback.run(); // Cập nhật tổng giá
            }
        });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    // Cập nhật danh sách món ăn
    public void updateOrderList(List<OrderModel> newOrderList) {
        this.orderList = newOrderList;
        notifyDataSetChanged();
    }

    // Lớp ViewHolder để quản lý item layout
    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView foodNameTextView, foodPriceTextView, foodQuantityTextView;
        ImageView foodImageView;
        View increaseButton, decreaseButton;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            foodNameTextView = itemView.findViewById(R.id.foodNameTextView);
            foodPriceTextView = itemView.findViewById(R.id.foodPriceTextView);
            foodQuantityTextView = itemView.findViewById(R.id.foodQuantityTextView);
            foodImageView = itemView.findViewById(R.id.foodImageView);
            increaseButton = itemView.findViewById(R.id.increaseButton);
            decreaseButton = itemView.findViewById(R.id.decreaseButton);
        }
    }
}
