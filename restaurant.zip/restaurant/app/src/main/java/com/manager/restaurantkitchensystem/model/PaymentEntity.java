package com.manager.restaurantkitchensystem.model;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "Payments",
        foreignKeys = @ForeignKey(
                entity = TableOrderEntity.class,
                parentColumns = "orderId",
                childColumns = "orderId"
        ),
        indices = @Index(value = "orderId") // Tạo chỉ mục cho cột orderId
)public class PaymentEntity {
    @PrimaryKey(autoGenerate = true)
    private int paymentId;

    private int orderId;
    private String paymentMethod; // Tiền mặt, Thẻ

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    private String paymentDate;
    private double amount;

    public PaymentEntity(int orderId, String paymentMethod, String paymentDate, double amount) {
        this.orderId = orderId;
        this.paymentMethod = paymentMethod;
        this.paymentDate = paymentDate;
        this.amount = amount;
    }

    // Getters and setters...
}
