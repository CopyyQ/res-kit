package com.manager.restaurantkitchensystem.model;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "TableOrders",
        foreignKeys = @ForeignKey(
                entity = TableEntity.class,
                parentColumns = "tableId",
                childColumns = "tableId"
        ),
        indices = @Index(value = "tableId") // Tạo chỉ mục cho cột tableId
)public class TableOrderEntity {
    @PrimaryKey(autoGenerate = true)
    private int orderId;

    private int tableId;
    private int waiterId;
    private String orderDate;
    private double totalAmount;
    private String orderStatus; // Đang chờ, Hoàn thành

    public TableOrderEntity(int tableId, int waiterId, String orderDate, double totalAmount, String orderStatus) {
        this.tableId = tableId;
        this.waiterId = waiterId;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
        this.orderStatus = orderStatus;
    }

    // Getter and setter for orderId
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    // Getter and setter for tableId
    public int getTableId() {
        return tableId;
    }

    public void setTableId(int tableId) {
        this.tableId = tableId;
    }

    // Getter and setter for waiterId
    public int getWaiterId() {
        return waiterId;
    }

    public void setWaiterId(int waiterId) {
        this.waiterId = waiterId;
    }

    // Getter and setter for orderDate
    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    // Getter and setter for totalAmount
    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    // Getter and setter for orderStatus
    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
}
