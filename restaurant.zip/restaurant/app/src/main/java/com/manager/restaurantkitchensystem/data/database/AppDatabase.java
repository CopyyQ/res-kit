package com.manager.restaurantkitchensystem.data.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.manager.restaurantkitchensystem.data.dao.TableDao;
import com.manager.restaurantkitchensystem.data.dao.TableOrderDao;
import com.manager.restaurantkitchensystem.model.KitchenOrderEntity;
import com.manager.restaurantkitchensystem.model.MenuEntity;
import com.manager.restaurantkitchensystem.model.OrderedDishEntity;
import com.manager.restaurantkitchensystem.model.PaymentEntity;
import com.manager.restaurantkitchensystem.model.TableEntity;
import com.manager.restaurantkitchensystem.model.TableOrderEntity;

@Database(entities = {
        TableEntity.class,
        TableOrderEntity.class,
        OrderedDishEntity.class,
        MenuEntity.class,
        KitchenOrderEntity.class,
        PaymentEntity.class
}, version = 2, exportSchema = false) // Tăng version từ 1 lên 2
public abstract class AppDatabase extends RoomDatabase {
    public abstract TableDao tableDao();
    public abstract TableOrderDao tableOrderDao();
    // Add other DAOs as needed
}

