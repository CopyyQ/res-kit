package com.manager.restaurantkitchensystem.model;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "KitchenOrders",
        foreignKeys = @ForeignKey(
                entity = OrderedDishEntity.class,
                parentColumns = "dishId",
                childColumns = "dishId"
        ),
        indices = @Index(value = "dishId") // Tạo chỉ mục cho cột dishId
)public class KitchenOrderEntity {
    @PrimaryKey(autoGenerate = true)
    private int kitchenId;

    public int getKitchenId() {
        return kitchenId;
    }

    public void setKitchenId(int kitchenId) {
        this.kitchenId = kitchenId;
    }

    public int getDishId() {
        return dishId;
    }

    public void setDishId(int dishId) {
        this.dishId = dishId;
    }

    public int getChefId() {
        return chefId;
    }

    public void setChefId(int chefId) {
        this.chefId = chefId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }

    private int dishId;
    private int chefId;
    private String status; // Đang nấu, Hoàn thành
    private String updatedTime;

    public KitchenOrderEntity(int dishId, int chefId, String status, String updatedTime) {
        this.dishId = dishId;
        this.chefId = chefId;
        this.status = status;
        this.updatedTime = updatedTime;
    }

    // Getters and setters...
}
