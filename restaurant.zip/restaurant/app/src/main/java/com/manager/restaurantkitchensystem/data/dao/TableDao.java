package com.manager.restaurantkitchensystem.data.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.manager.restaurantkitchensystem.model.TableEntity;

import java.util.List;

@Dao
public interface TableDao {
    @Query("SELECT * FROM Tables")
    List<TableEntity> getAllTables();

    @Query("SELECT * FROM Tables WHERE status = :status")
    List<TableEntity> getTablesByStatus(String status);

    @Insert
    void insertTable(TableEntity table);

    @Update
    void updateTable(TableEntity table);
}
