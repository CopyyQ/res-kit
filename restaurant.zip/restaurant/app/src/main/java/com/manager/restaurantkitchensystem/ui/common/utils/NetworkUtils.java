package com.manager.restaurantkitchensystem.ui.common.utils;

public class NetworkUtils {
}
