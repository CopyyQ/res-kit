package com.manager.restaurantkitchensystem.ui.common;

public class BaseViewModel {
}
