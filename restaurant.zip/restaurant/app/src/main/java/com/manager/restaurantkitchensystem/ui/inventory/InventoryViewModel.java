package com.manager.restaurantkitchensystem.ui.inventory;

public class InventoryViewModel {
}
