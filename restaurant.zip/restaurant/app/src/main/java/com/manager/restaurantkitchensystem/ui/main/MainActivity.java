package com.manager.restaurantkitchensystem.ui.main;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.manager.restaurantkitchensystem.R;
import com.manager.restaurantkitchensystem.databinding.ActivityMainBinding;
import com.manager.restaurantkitchensystem.ui.hr.HRFragment;
import com.manager.restaurantkitchensystem.ui.inventory.InventoryFragment;
import com.manager.restaurantkitchensystem.ui.kitchen.KitchenFragment;
import com.manager.restaurantkitchensystem.ui.order.OrderFragment;
import com.manager.restaurantkitchensystem.ui.payment.PaymentFragment;
import com.manager.restaurantkitchensystem.ui.table.TableFragment;


public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        replaceFragment(new TableFragment());
        binding.bottomNavigationView.setBackground(null);

        binding.bottomNavigationView.setOnItemSelectedListener(item -> {

            if (item.getItemId() == R.id.table) {
                replaceFragment(new TableFragment());
            } else if (item.getItemId() == R.id.kitchen) {
                replaceFragment(new KitchenFragment());
            } else if (item.getItemId() == R.id.payment) {
                replaceFragment(new PaymentFragment());
            }
//            else if (item.getItemId() == R.id.hr) {
//                replaceFragment(new HRFragment());
//            }
            else if (item.getItemId() == R.id.inventory ) {
                replaceFragment(new InventoryFragment());
            }


            return true;

        });
        // Floating Action Button Click Listener
        binding.floatingActionButton.setOnClickListener(v -> {
            // Open OrderFragment when FAB is clicked
            replaceFragment(new OrderFragment());
        });

    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }
}