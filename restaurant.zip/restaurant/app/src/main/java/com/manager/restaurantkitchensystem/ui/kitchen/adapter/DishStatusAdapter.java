package com.manager.restaurantkitchensystem.ui.kitchen.adapter;

public class DishStatusAdapter {
}
