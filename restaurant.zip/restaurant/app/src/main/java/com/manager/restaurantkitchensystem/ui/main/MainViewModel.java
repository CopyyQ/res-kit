package com.manager.restaurantkitchensystem.ui.main;

public class MainViewModel {
}
