package com.manager.restaurantkitchensystem.data.repository;

public class InventoryRepository {
}
