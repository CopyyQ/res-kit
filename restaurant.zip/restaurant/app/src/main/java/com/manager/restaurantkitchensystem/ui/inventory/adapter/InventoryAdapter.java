package com.manager.restaurantkitchensystem.ui.inventory.adapter;

public class InventoryAdapter {
}
