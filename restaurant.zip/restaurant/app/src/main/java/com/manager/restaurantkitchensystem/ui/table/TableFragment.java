package com.manager.restaurantkitchensystem.ui.table;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.manager.restaurantkitchensystem.R;
import com.manager.restaurantkitchensystem.data.database.AppDatabase;
import com.manager.restaurantkitchensystem.data.database.DatabaseModule;
import com.manager.restaurantkitchensystem.model.TableEntity;
import com.manager.restaurantkitchensystem.ui.table.adapter.TableAdapter;

import java.util.ArrayList;
import java.util.List;

public class TableFragment extends Fragment {

    private RecyclerView tableRecyclerView;
    private TableAdapter tableAdapter;
    private List<TableEntity> tableList;
    private Spinner filterSpinner;
    private AppDatabase database;

    public TableFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_table, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        database = DatabaseModule.getDatabase(requireContext());

        // Initialize RecyclerView
        tableRecyclerView = view.findViewById(R.id.tableRecyclerView);
        tableRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        // Initialize Spinner
        filterSpinner = view.findViewById(R.id.filterSpinner);

        // Thiết lập sự kiện khi chọn bộ lọc
        filterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                // Lấy tùy chọn được chọn
                String selectedFilter = adapterView.getItemAtPosition(position).toString();
                // Cập nhật danh sách bàn theo bộ lọc
                fetchTables(selectedFilter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Nếu không chọn gì, hiển thị tất cả
                fetchTables("Tất cả");
            }
        });

        // Lần đầu tiên, hiển thị tất cả
        fetchTables("Tất cả");
    }

    private void fetchTables(String filter) {
        new Thread(() -> {
            // Nếu cơ sở dữ liệu trống, thêm 10 bàn giả lập
            if (database.tableDao().getAllTables().isEmpty()) {
                tableList = new ArrayList<>();
                for (int i = 1; i <= 10; i++) {
                    TableEntity table = new TableEntity("Bàn " + i, 4, "Trống");
                    tableList.add(table);
                    database.tableDao().insertTable(table);
                }
            }

            // Lấy danh sách bàn theo bộ lọc
            switch (filter) {
                case "Bàn trống":
                    tableList = database.tableDao().getTablesByStatus("Trống");
                    break;
                case "Bàn đã dùng":
                    tableList = database.tableDao().getTablesByStatus("Đang sử dụng");
                    break;
                default:
                    tableList = database.tableDao().getAllTables();
                    break;
            }

            // Cập nhật RecyclerView trên luồng chính
            requireActivity().runOnUiThread(() -> {
                if (tableAdapter == null) {
                    tableAdapter = new TableAdapter(tableList);
                    tableRecyclerView.setAdapter(tableAdapter);
                } else {
                    tableAdapter.updateTableList(tableList);
                }
            });
        }).start();
    }
}
