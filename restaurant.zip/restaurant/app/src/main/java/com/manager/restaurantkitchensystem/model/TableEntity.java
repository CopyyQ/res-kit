package com.manager.restaurantkitchensystem.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Tables")
public class TableEntity {
    @PrimaryKey(autoGenerate = true)
    private int tableId;

    private String tableNumber;
    private int capacity;
    private String status; // Trống, Đang sử dụng

    public TableEntity(String tableNumber, int capacity, String status) {
        this.tableNumber = tableNumber;
        this.capacity = capacity;
        this.status = status;
    }

    public int getTableId() {
        return tableId;
    }

    public void setTableId(int tableId) {
        this.tableId = tableId;
    }

    public String getTableNumber() {
        return tableNumber;
    }

    public void setTableNumber(String tableNumber) {
        this.tableNumber = tableNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
