package com.manager.restaurantkitchensystem.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Menu")
public class MenuEntity {
    @PrimaryKey(autoGenerate = true)
    private int menuItemId;

    private String dishName;
    private String category; // Khai vị, Chính, Tráng miệng
    private double price;

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDishName() {
        return dishName;
    }

    public void setDishName(String dishName) {
        this.dishName = dishName;
    }

    public int getMenuItemId() {
        return menuItemId;
    }

    public void setMenuItemId(int menuItemId) {
        this.menuItemId = menuItemId;
    }

    public MenuEntity(String dishName, String category, double price) {
        this.dishName = dishName;
        this.category = category;
        this.price = price;
    }

    // Getters and setters...
}
