package com.manager.restaurantkitchensystem.data.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.Executors;

public class DatabaseModule {
    private static AppDatabase databaseInstance;

    private static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            // Thêm chỉ mục cho tableId trong bảng TableOrders
            database.execSQL("CREATE INDEX index_TableOrders_tableId ON TableOrders(tableId)");
        }
    };

    public static synchronized AppDatabase getDatabase(Context context) {
        if (databaseInstance == null) {
            databaseInstance = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "restaurant_database"
                    )
                    .addMigrations(MIGRATION_1_2) // Thêm logic migration
                    .build();
        }
        return databaseInstance;
    }
}
