package com.manager.restaurantkitchensystem.ui.payment;

public class PaymentViewModel {
}
