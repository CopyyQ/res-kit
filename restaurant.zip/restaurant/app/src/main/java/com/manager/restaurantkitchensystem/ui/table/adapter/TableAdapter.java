package com.manager.restaurantkitchensystem.ui.table.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.manager.restaurantkitchensystem.R;
import com.manager.restaurantkitchensystem.data.database.AppDatabase;
import com.manager.restaurantkitchensystem.data.database.DatabaseModule;
import com.manager.restaurantkitchensystem.model.TableEntity;

import java.util.List;

public class TableAdapter extends RecyclerView.Adapter<TableAdapter.TableViewHolder> {

    private List<TableEntity> tableList;

    public TableAdapter(List<TableEntity> tableList) {
        this.tableList = tableList;
    }

    @NonNull
    @Override
    public TableViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_table, parent, false);
        return new TableViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TableViewHolder holder, int position) {
        TableEntity table = tableList.get(position);

        // Set table information to views
        holder.tableNumberTextView.setText("Bàn: " + table.getTableNumber());
        holder.tableStatusTextView.setText("Trạng thái: " + table.getStatus());
        holder.tableCapacityTextView.setText("Sức chứa: " + table.getCapacity() + " người");

        // Example: Update status on click
        holder.itemView.setOnClickListener(v -> {
            String newStatus = table.getStatus().equals("Trống") ? "Đang sử dụng" : "Trống";
            table.setStatus(newStatus);

            // Update status in database
            new Thread(() -> {
                AppDatabase database = DatabaseModule.getDatabase(holder.itemView.getContext());
                database.tableDao().updateTable(table);
            }).start();

            // Update UI
            holder.tableStatusTextView.setText("Trạng thái: " + newStatus);
        });
    }

    @Override
    public int getItemCount() {
        return tableList.size();
    }

    public void updateTableList(List<TableEntity> newTableList) {
        this.tableList = newTableList;
        notifyDataSetChanged();
    }

    public static class TableViewHolder extends RecyclerView.ViewHolder {
        TextView tableNumberTextView, tableStatusTextView, tableCapacityTextView;

        public TableViewHolder(@NonNull View itemView) {
            super(itemView);
            tableNumberTextView = itemView.findViewById(R.id.tableNumberTextView);
            tableStatusTextView = itemView.findViewById(R.id.tableStatusTextView);
            tableCapacityTextView = itemView.findViewById(R.id.tableCapacityTextView);
        }
    }
}
