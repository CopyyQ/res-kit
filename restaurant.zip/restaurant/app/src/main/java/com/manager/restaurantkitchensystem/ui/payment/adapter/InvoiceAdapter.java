package com.manager.restaurantkitchensystem.ui.payment.adapter;

public class InvoiceAdapter {
}
