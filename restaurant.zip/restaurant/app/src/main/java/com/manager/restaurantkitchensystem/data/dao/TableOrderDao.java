package com.manager.restaurantkitchensystem.data.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.manager.restaurantkitchensystem.model.TableOrderEntity;

import java.util.List;

@Dao
public interface TableOrderDao {
    @Query("SELECT * FROM TableOrders WHERE tableId = :tableId")
    List<TableOrderEntity> getOrdersForTable(int tableId);

    @Insert
    void insertOrder(TableOrderEntity order);

    @Update
    void updateOrder(TableOrderEntity order);

    @Delete
    void deleteOrder(TableOrderEntity order);
}
