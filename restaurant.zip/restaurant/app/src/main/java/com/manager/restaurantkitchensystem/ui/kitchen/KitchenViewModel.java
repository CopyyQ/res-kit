package com.manager.restaurantkitchensystem.ui.kitchen;

public class KitchenViewModel {
}
