package com.manager.restaurantkitchensystem.model;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "OrderedDishes",
        foreignKeys = @ForeignKey(
                entity = TableOrderEntity.class,
                parentColumns = "orderId",
                childColumns = "orderId"
        ),
        indices = @Index(value = "orderId") // Tạo chỉ mục cho cột orderId
)public class OrderedDishEntity {
    @PrimaryKey(autoGenerate = true)
    private int dishId;

    private int orderId;

    public int getDishId() {
        return dishId;
    }

    public void setDishId(int dishId) {
        this.dishId = dishId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getMenuItemId() {
        return menuItemId;
    }

    public void setMenuItemId(int menuItemId) {
        this.menuItemId = menuItemId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getKitchenStatus() {
        return kitchenStatus;
    }

    public void setKitchenStatus(String kitchenStatus) {
        this.kitchenStatus = kitchenStatus;
    }

    private int menuItemId;
    private int quantity;
    private double price;
    private String kitchenStatus; // Đang nấu, Hoàn thành

    public OrderedDishEntity(int orderId, int menuItemId, int quantity, double price, String kitchenStatus) {
        this.orderId = orderId;
        this.menuItemId = menuItemId;
        this.quantity = quantity;
        this.price = price;
        this.kitchenStatus = kitchenStatus;
    }

    // Getters and setters...
}
