package com.manager.restaurantkitchensystem.ui.hr;

public class HRViewModel {
}
