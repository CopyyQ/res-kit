package com.manager.restaurantkitchensystem.data.repository;

import com.manager.restaurantkitchensystem.data.dao.TableDao;
import com.manager.restaurantkitchensystem.data.database.AppDatabase;

import java.util.List;

public class TableRepository {
    private final TableDao tableDao;

    public TableRepository(AppDatabase database) {
        this.tableDao = database.tableDao();
    }


}
