package com.manager.restaurantkitchensystem.ui.order;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.manager.restaurantkitchensystem.R;
import com.manager.restaurantkitchensystem.data.database.AppDatabase;
import com.manager.restaurantkitchensystem.data.database.DatabaseModule;
import com.manager.restaurantkitchensystem.model.TableEntity;
import com.manager.restaurantkitchensystem.ui.order.adapter.OrderAdapter;

import java.util.ArrayList;
import java.util.List;

public class OrderFragment extends Fragment {

    private RecyclerView orderRecyclerView;
    private OrderAdapter orderAdapter;
    private List<OrderModel> orderList;
    private Spinner categorySpinner;
    private TextView totalPriceTextView;

    public OrderFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_order, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize UI components
        Spinner tableSpinner = view.findViewById(R.id.tableSpinner); // Spinner chọn bàn
        categorySpinner = view.findViewById(R.id.categorySpinner); // Spinner chọn danh mục món ăn
        orderRecyclerView = view.findViewById(R.id.orderRecyclerView); // RecyclerView hiển thị món ăn
        totalPriceTextView = view.findViewById(R.id.totalPriceTextView); // TextView hiển thị tổng giá
        TextView checkoutButton = view.findViewById(R.id.checkoutButton); // Nút Thanh toán

        // Set up RecyclerView
        orderRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Lấy danh sách bàn từ cơ sở dữ liệu
        new Thread(() -> {
            AppDatabase database = DatabaseModule.getDatabase(requireContext());
            List<TableEntity> tableEntities = database.tableDao().getAllTables(); // Lấy danh sách bàn

            // Chuyển đổi danh sách TableEntity thành String để hiển thị trong Spinner
            List<String> tableList = new ArrayList<>();
            tableList.add("Chọn bàn"); // Thêm tùy chọn mặc định
            for (TableEntity table : tableEntities) {
                tableList.add("Bàn " + table.getTableNumber());
            }

            // Cập nhật UI trên luồng chính
            requireActivity().runOnUiThread(() -> {
                // Adapter cho Spinner chọn bàn
                ArrayAdapter<String> tableAdapter = new ArrayAdapter<>(
                        requireContext(),
                        android.R.layout.simple_spinner_item,
                        tableList
                );
                tableAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                tableSpinner.setAdapter(tableAdapter);

                // Xử lý sự kiện chọn bàn
                tableSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String selectedTable = tableList.get(position);
                        if (!selectedTable.equals("Chọn bàn")) {
                            showCustomSnackbar(view, "Bạn đã chọn " + selectedTable);
                        }
                    }


                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        // Không làm gì nếu không chọn bàn
                    }
                });
            });
        }).start();

        // Tạo dữ liệu mẫu cho món ăn
        orderList = new ArrayList<>();
        orderList.add(new OrderModel("Salad", "Khai vị", 50000, 1, R.drawable.basket));
        orderList.add(new OrderModel("Soup", "Khai vị", 60000, 1, R.drawable.basket));
        orderList.add(new OrderModel("Steak", "Món chính", 150000, 1, R.drawable.basket));
        orderList.add(new OrderModel("Pasta", "Món chính", 120000, 1, R.drawable.basket));
        orderList.add(new OrderModel("Ice Cream", "Tráng miệng", 40000, 1, R.drawable.basket));

        // Set up Adapter cho RecyclerView
        orderAdapter = new OrderAdapter(orderList, this::updateTotalPrice);
        orderRecyclerView.setAdapter(orderAdapter);

        // Tạo dữ liệu mẫu cho Spinner danh mục món ăn
        List<String> categories = new ArrayList<>();
        categories.add("Tất cả");
        categories.add("Khai vị");
        categories.add("Món chính");
        categories.add("Tráng miệng");

        // Adapter cho Spinner danh mục món ăn
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                categories
        );
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        // Xử lý sự kiện chọn danh mục món ăn
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = categories.get(position);
                filterOrdersByCategory(selectedCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Không làm gì nếu không chọn
            }
        });

        // Xử lý sự kiện nút Thanh toán
        checkoutButton.setOnClickListener(v -> {
            Toast.makeText(requireContext(), "Đã thanh toán!", Toast.LENGTH_SHORT).show();
        });

        // Cập nhật tổng giá tiền ban đầu
        updateTotalPrice();
    }


    private void updateTotalPrice() {
        int totalPrice = 0;
        for (OrderModel order : orderList) {
            totalPrice += order.getPrice() * order.getQuantity();
        }
        totalPriceTextView.setText("Tổng: " + totalPrice + " VND");
    }

    private void filterOrdersByCategory(String category) {
        List<OrderModel> filteredList;
        if (category.equals("Tất cả")) {
            filteredList = new ArrayList<>(orderList); // Hiển thị tất cả món
        } else {
            filteredList = new ArrayList<>();
            for (OrderModel order : orderList) {
                if (order.getCategory().equals(category)) {
                    filteredList.add(order);
                }
            }
        }

        // Cập nhật RecyclerView với danh sách đã lọc
        orderAdapter.updateOrderList(filteredList);
    }

    private void showCustomSnackbar(View parentView, String message) {
        Snackbar snackbar = Snackbar.make(parentView, message, Snackbar.LENGTH_SHORT);
        View snackbarView = snackbar.getView();

        // Tùy chỉnh giao diện
        snackbarView.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.primaryColor)); // Đổi màu nền
        TextView textView = snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextColor(ContextCompat.getColor(requireContext(), R.color.white)); // Đổi màu chữ
        textView.setTextSize(16); // Đổi kích thước chữ
        textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        snackbar.show();
    }


}
