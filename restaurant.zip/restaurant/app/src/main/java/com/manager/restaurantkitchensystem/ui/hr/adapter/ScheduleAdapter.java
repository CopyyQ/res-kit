package com.manager.restaurantkitchensystem.ui.hr.adapter;

public class ScheduleAdapter {
}
